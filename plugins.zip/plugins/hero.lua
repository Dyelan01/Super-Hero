--[[ 
▀▄ ▄▀▀▄▄▀▀▄▄▀▀▄▄▀▀▄▄▀▀▄▄▀▀▄▄▀▀▄▀▄▄▀▀▄▄▀▀▄▄▀▀▄▄▀▀          
▀▄ ▄▀                                      ▀▄ ▄▀ 
▀▄ ▄▀    BY SAJJAD NOORI                   ▀▄ ▄▀ 
▀▄ ▄▀     BY SAJAD NOORI (@SAJJADNOORI)    ▀▄ ▄▀ 
▀▄ ▄▀ JUST WRITED BY SAJJAD NOORI          ▀▄ ▄▀   
▀▄ ▄▀          dev1  : dev                 ▀▄ ▄▀ 
▀▄▀▀▄▄▀▀▄▄▀▄▄▀▀▄▄▀▀▄▄▀▄▄▀▀▄▄▀▀▄▄▀▄▄▀▀▄▄▀▀▄▄▀▄▄▀▀
—]]
do

function run(msg, matches)
return [[
♠️♠️♠️♠️♠️♠️♠️♠️♠️♠️

تــم صنع هذ البوت من قبل المطور 

ديلان ™ @Dyelan 🔕🌝

@Faum_bot

♠️ ♠️♠️♠️♠️♠️♠️♠️♠️♠️
]]
end

return {
description = "Shows bot q", 
usage = "spam Shows bot q",
patterns = {
"^(h3)$",
},
run = run 
}
end